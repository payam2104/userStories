import { Component, Input, signal, Signal, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CdkDragDrop, DragDropModule } from '@angular/cdk/drag-drop';

import { Issue } from '../../../core/model/issue.model';
import { Step } from '../../../core/model/step.model';
import { IssueCardComponent } from '../issue-card/issue-card.component';

// Komponente zur Darstellung eines einzelnen Steps innerhalb einer Journey-Spalte
// Zeigt die zugehörigen Issues an und ermöglicht Drag & Drop-Zuordnung
@Component({
  selector: 'app-step-box',
  standalone: true,
  imports: [CommonModule, DragDropModule, IssueCardComponent],
  templateUrl: './step-box.component.html',
  styleUrls: ['./step-box.component.scss']
})
export class StepBoxComponent {
  @Input() step?: Signal<Step>;
  @Input() issues: Signal<Issue[]> = signal([]);
  @Input() connectedDropListIds: string[] = [];
  @Output() dropped = new EventEmitter<CdkDragDrop<Issue[]>>();

}
