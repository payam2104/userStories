export interface Release {
  id: string;  // UUID
  name: string;
  description?: string;
}
