export interface Release {
  id: string;
  name: string;
  description?: string;
}
