export interface Step {
  id: string;  // UUID
  name: string;
  user_journey_id: string;
}
