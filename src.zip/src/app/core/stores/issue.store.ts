import { computed, Injectable, signal } from '@angular/core';
import { Issue } from '../model/issue.model';
import { issueDB } from '../services/issue-db.service';

@Injectable({ providedIn: 'root' })
export class IssueStore {
  private readonly _issues = signal<Issue[]>([]);
  readonly issues = this._issues.asReadonly();

  constructor() {
    this.initFromDB();
  }

  // Initialdaten aus IndexedDB laden (nur beim ersten Mal seeden)
  async initFromDB() {
    await issueDB.seedInitialIssues([
      { id: 'GL-001', title: 'Login-Fehlereeee', description: 'Fehlermeldung bei ungültigem Passwort' },
      { id: 'GL-002', title: 'Suchfunktion verbessern', description: 'Suche reagiert zu langsam' },
      { id: 'GL-003', title: 'Dark Mode hinzufügen', description: 'Thema wird oft gewünscht' },
      { id: 'GL-004', title: 'Release Info anzeigen', description: 'Anzeige der aktuellen Version im Footer' },
      { id: 'GL-005', title: 'Registrierung optimieren', description: 'Doppelte Eingabefelder vermeiden' }
    ]);

    const issues = await issueDB.getAll();
    this._issues.set(issues);
  }

  // Nicht zugeordnete Issues (stepId fehlt)
  readonly unassignedIssues = computed(() =>
    this._issues().filter(issue => !issue.stepId)
  );

  // einem Step zuweisen
  assignToStep(issueId: string, stepId: string): void {
    this._issues.update(issues =>
      issues.map(issue =>
        issue.id === issueId ? { ...issue, stepId } : issue
      )
    );
    issueDB.updateStep(issueId, stepId);
  }

  // einem Release zuweisen (optional)
  assignToRelease(issueId: string, releaseId: string) {
    this._issues.update(list =>
      list.map(issue =>
        issue.id === issueId ? { ...issue, releaseId } : issue
      )
    );
    // TODO: falls du releaseDB hast, auch dort speichern
  }

  // von Step trennen
  unassignFromStep(issueId: string) {
    this._issues.update(list =>
      list.map(issue =>
        issue.id === issueId ? { ...issue, stepId: undefined } : issue
      )
    );
    issueDB.updateStep(issueId, undefined); // setzt stepId zurück
  }

  setIssues(issues: Issue[]) {
    this._issues.set(issues);
  }

  async resetAll() {
    await issueDB.issues.clear();
    await this.initFromDB(); // reused dieselbe Logik
  }
}

